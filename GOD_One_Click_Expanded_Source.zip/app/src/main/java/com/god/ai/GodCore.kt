package com.god.ai

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

class GodCore(private val context: Context) {
    private val prefs = context.getSharedPreferences("god", Context.MODE_PRIVATE)

    var apiKey: String
        get() = prefs.getString("api_key", "") ?: ""
        set(v) { prefs.edit().putString("api_key", v).apply() }

    fun route(raw: String): String {
        val q = raw.trim()
        val lower = q.lowercase()

        if (lower == "go to home" || lower == "go to home screen" || lower == "home") {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            context.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Going to the home screen."
        }

        if (lower.startsWith("open youtube")) {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Opening YouTube."
        }

        if (lower.startsWith("search youtube for ")) {
            val query = q.substringAfter("search youtube for ").trim()
            val url = "https://www.youtube.com/results?search_query=" + Uri.encode(query)
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Searching YouTube for: $query"
        }

        if (lower == "back") {
            context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Android controls the Back action; use the system Back gesture/button."
        }

        if (apiKey.isBlank()) return "Open Settings and enter your Gemini API key first."

        return "GOD received: $q

The Gemini API/tool layer is ready to be connected. This starter keeps your API key local and does not embed it in the source."
    }
}
