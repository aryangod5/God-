package com.god.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var tts: TextToSpeech
    private lateinit var core: GodCore
    private lateinit var input: EditText
    private lateinit var answer: TextView
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        core = GodCore(this)
        input = findViewById(R.id.input)
        answer = TextView(this)
        status = findViewById(R.id.status)
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts.language = Locale.getDefault() }

        findViewById<Button>(R.id.send).setOnClickListener { ask(input.text.toString()) }
        findViewById<Button>(R.id.voice).setOnClickListener { startVoice() }
        findViewById<Button>(R.id.settings).setOnClickListener { settings() }
        findViewById<Button>(R.id.file).setOnClickListener { chooseFolder() }
        findViewById<Button>(R.id.permissions).setOnClickListener { requestMic() }
        findViewById<Button>(R.id.biometric).setOnClickListener { biometric() }
    }

    private fun ask(q: String) {
        if (q.isBlank()) return
        status.text = "Thinking..."
        Thread {
            val r = core.route(q)
            runOnUiThread {
                status.text = "Ready"
                show(r)
            }
        }.start()
    }

    private fun show(s: String) {
        answer.text = s
        tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "GOD")
    }

    private fun settings() {
        val e = EditText(this)
        e.hint = "Gemini API key"
        e.setText(core.apiKey)
        AlertDialog.Builder(this).setTitle("GOD Settings")
            .setMessage("Your API key is stored locally. Do not put it in GitHub.")
            .setView(e).setPositiveButton("SAVE") { _, _ -> core.apiKey = e.text.toString().trim() }
            .setNegativeButton("CANCEL", null).show()
    }

    private fun startVoice() {
        if (!has(Manifest.permission.RECORD_AUDIO)) { requestMic(); return }
        startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to GOD")
        }, 101)
    }

    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d)
        if (r == 101 && c == RESULT_OK) {
            val s = d?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (s != null) { input.setText(s); ask(s) }
        }
    }

    private fun chooseFolder() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }, 102)
    }

    private fun requestMic() {
        if (!has(Manifest.permission.RECORD_AUDIO))
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        else Toast.makeText(this, "Microphone permission is already granted.", Toast.LENGTH_SHORT).show()
    }

    private fun has(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun biometric() {
        Toast.makeText(this, "Biometric integration can be enabled here using Android BiometricPrompt.", Toast.LENGTH_LONG).show()
    }
}
