# Minimum-work build

1. Upload the contents of this project to a GitHub repository.
2. Open **Actions**.
3. Select **Build GOD APK**.
4. Press **Run workflow**.
5. Download the `GOD-debug-apk` artifact.

No Android Studio or Shizuku is required.

Important: this project is a foundation and does NOT magically implement unrestricted phone control. Android permissions and security boundaries still apply.
